SELECT
	*
FROM
	[HumanResources].[Department];